function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
function HosegriadoSzint(nap1, nap2, nap3) {
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
        return 3;
    }
    else if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25) {
        return 2;
    }
    else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    }
    else {
        return 0;
    }
}
function OszthatoSzamok(oszto, vizsgalTomb) {
    var ret = 0;
    for (var i = 0; i < vizsgalTomb.length; i++) {
        if (vizsgalTomb[i] % oszto == 0) {
            ret++;
        }
    }
    return ret;
}
function KorKeruletTerulet(sugar) {
    var terulet = sugar * sugar * Math.PI;
    var kerulet = sugar * 2 * Math.PI;
    return [kerulet.toFixed(1), terulet.toFixed(1)];
}
function Erettsegi(pontok) {
    var osszpont = 0;
    var jegy = 0;
    for (var i = 0; i < pontok.length; i++) {
        osszpont = osszpont + pontok[i];
    }
    if (osszpont <= 39 && osszpont >= 0) {
        jegy = 1;
    }
    else if (osszpont >= 40 && osszpont <= 59) {
        jegy = 2;
    }
    else if (osszpont >= 60 && osszpont <= 79) {
        jegy = 3;
    }
    else if (osszpont >= 80 && osszpont <= 119) {
        jegy = 4;
    }
    else if (osszpont >= 119 && osszpont <= 150) {
        jegy = 5;
    }
    return [osszpont, jegy];
}
function LeetKod(vizsgaltSzoveg) {
    return vizsgaltSzoveg.replace(/i/gi, "1").replace(/o/gi, "0").replace(/a/gi, "4").replace(/e/gi, "3");
}
var snookerInfo = ["52;Akani Sunny;Thaiföld;118500",
    "7;Allen Mark;Észak-Írország;681000",
    "72;Anda Zhang;Kína;44750",
    "76;Astley John;Anglia;40000",
    "73;Baird Sam;Anglia;44750",
    "13;Bingham Stuart;Anglia;345500",
    "97;Bingyu Chang;Kína;6750",
    "28;Brecel Luca;Belgium;179000",
    "79;Brown Jordan;Észak-Írország;29000",
    "78;Burden Alfred;Anglia;32000",
    "50;Carrington Stuart;Anglia;121750",
    "16;Carter Ali;Anglia;289000",
    "81;Carty Ashley;Anglia;22750",
    "86;Chandler Harvey;Anglia;14475",
    "83;Chuan Leong Thor;Malajzia;16500",
    "84;Clarke Jamie Rhys;Wales;15500",
    "63;Craigie Sam;Anglia;78500",
    "94;Dale Dominic;Wales;8750",
    "41;Davis Mark;Anglia;145725",
    "20;Day Ryan;Wales;244250",
    "18;Ding Junhui;Kína;270250",
    "64;Doherty Ken;Írország;77250",
    "29;Donaldson Scott;Skócia;176750",
    "21;Dott Graeme;Skócia;237750",
    "66;Dunn Mike;Anglia;74750",
    "53;Ebdon Peter;Anglia;111750",
    "88;Feilong Chen;Kína;13500",
    "22;Ford Tom;Anglia;212250",
    "57;Fu Marco;Hong Kong;104250",
    "51;Georgiou Michael;Ciprus;119600",
    "11;Gilbert David;Anglia;412000",
    "33;Gould Martin;Anglia;160250",
    "99;Grace David;Anglia;6750",
    "24;Guodong Xiao;Kína;211600",
    "61;Hamilton Anthony;Anglia;92250",
    "25;Haotian Lyu;Kína;191750",
    "10;Hawkins Barry;Anglia;427250",
    "91;Heathcote Louis;Anglia;10750",
    "6;Higgins John;Skócia;743000",
    "59;Higginson Andrew;Anglia;96250",
    "60;Highfield Liam;Anglia;96000",
    "89;Hirani Kishan;Wales;13350",
    "44;Holt Michael;Anglia;133500",
    "70;Honghao Luo;Kína;65000",
    "95;Jiahui Si;Kína;7500",
    "87;Jiankang Zhang;Kína;13600",
    "71;Jones Jak;Wales;54250",
    "48;Joyce Mark;Anglia;125750",
    "30;King Mark;Anglia;166500",
    "100;Langning Bai;Kína;5000",
    "92;Lee Andy;Anglia;9500",
    "43;Li Hang;Kína;138000",
    "36;Liang Wenbo;Kína;154500",
    "80;Lines Oliver;Anglia;28000",
    "12;Lisowski Jack;Anglia;392250",
    "34;Maflin Kurt;Norvégia;158600",
    "14;Maguire Stephen;Skócia;316000",
    "96;Mann Mitchell;Anglia;7500",
    "32;McGill Anthony;Skócia;160500",
    "54;McManus Alan;Skócia;111250",
    "85;Miah Hammad;Anglia;15475",
    "39;Milkins Robert;Anglia;149600",
    "8;Murphy Shaun;Anglia;506500",
    "62;Ning Lu;Kína;87250",
    "67;O'Brien Fergal;Írország;70600",
    "68;O'Connor Joe;Anglia;69750",
    "42;O'Donnell Martin;Anglia;145250",
    "2;O'Sullivan Ronnie;Anglia;1116000",
    "65;Pengfei Tian;Kína;75750",
    "15;Perry Joe;Anglia;292500",
    "23;Robertson Jimmy;Anglia;211725",
    "5;Robertson Neil;Ausztrália;834500",
    "35;Saengkham Noppon;Thaiföld;157000",
    "4;Selby Mark;Anglia;863000",
    "27;Selt Matthew;Anglia;180350",
    "49;Sijun Yuan;Kína;123000",
    "74;Slessor Elliot;Anglia;43500",
    "75;Steadman Craig;Anglia;40500",
    "90;Stefanow Adam;Lengyelország;12500",
    "46;Stevens Matthew;Wales;129750",
    "1;Trump Judd;Anglia;1270500",
    "37;Un-Nooh Thepchaiya;Thaiföld;151225",
    "98;Ursenbacher Alexander;Svájc;6750",
    "31;Vafaei Hossein;Irán;161500",
    "45;Wakelin Chris;Anglia;129975",
    "26;Walden Ricky;Anglia;182750",
    "77;Walker Lee;Wales;33000",
    "82;Wattana James;Thaiföld;17500",
    "56;Wells Daniel;Wales;104250",
    "58;White Michael;Wales;98250",
    "3;Williams Mark;Wales;1048250",
    "55;Williams Robbie;Anglia;107500",
    "19;Wilson Gary;Anglia;261100",
    "9;Wilson Kyren;Anglia;470500",
    "40;Woollaston Ben;Anglia;146350",
    "47;Xintong Zhao;Kína;125750",
    "69;Xiwen Mei;Kína;68000",
    "17;Yan Bingtao;Kína;285000",
    "93;Zhengyi Fan;Kína;9500",
    "38;Zhou Yuelong;Kína;150250",
];
function ObjektumFeltolto(feltoltendoElem) {
    var beolvasottAdatok = [];
    for (var i = 0; i < feltoltendoElem.length; i++) {
        var daraboltAdatok = feltoltendoElem[i].split(";");
        var snooker = {
            helyezes: Number(daraboltAdatok[0]),
            nev: daraboltAdatok[1],
            orszag: daraboltAdatok[2],
            penz: Number(daraboltAdatok[3])
        };
        beolvasottAdatok.push(snooker);
    }
    return beolvasottAdatok;
}
var snookerAdatok = ObjektumFeltolto(snookerInfo);
function LegtobbNyeremeny(vizsgaltObjektum) {
    var nyeremeny = 0;
    for (var i = 0; i < vizsgaltObjektum.length; i++) {
        if (vizsgaltObjektum[i].penz > nyeremeny) {
            nyeremeny = vizsgaltObjektum[i].penz;
        }
    }
    return nyeremeny;
}
//TESZT
function FuggvenyVisszajelzoSor(tesztNeve, adatBe, elvartEredmeny, fuggvenyhivas) {
    //Tábla elemek létrehozása
    var table = document.querySelector("#backupTable");
    var adatSor = table.insertRow(1);
    var tesztNeveMezo = adatSor.insertCell(0);
    var bemenetMezo = adatSor.insertCell(1);
    var elvartEredmenyMezo = adatSor.insertCell(2);
    var fuggvenyEredmenyMezo = adatSor.insertCell(3);
    var visszajelzesMezo = adatSor.insertCell(4);
    //Teszt paraméterek megadása és megjelenítése
    tesztNeveMezo.innerHTML = "".concat(tesztNeve);
    bemenetMezo.innerHTML = "".concat(adatBe);
    elvartEredmenyMezo.innerHTML = "".concat(elvartEredmeny);
    fuggvenyEredmenyMezo.innerHTML = "".concat(fuggvenyhivas);
    if (elvartEredmeny == fuggvenyhivas) {
        visszajelzesMezo.innerHTML = "Success";
    }
    else {
        visszajelzesMezo.innerHTML = "Fail";
    }
}
//Hibás referencia érték esetén lefutó függvény
function HibasFuggvenyFuggvenyVisszajelzoSor(tesztNeve, adatBe, elvartEredmeny) {
    var table = document.querySelector("#backupTable");
    var adatSor = table.insertRow(1);
    var tesztNeveMezo = adatSor.insertCell(0);
    var bemenetMezo = adatSor.insertCell(1);
    var elvartEredmenyMezo = adatSor.insertCell(2);
    var fuggvenyEredmenyMezo = adatSor.insertCell(3);
    var visszajelzesMezo = adatSor.insertCell(4);
    tesztNeveMezo.innerHTML = "".concat(tesztNeve);
    bemenetMezo.innerHTML = "".concat(adatBe);
    elvartEredmenyMezo.innerHTML = "".concat(elvartEredmeny);
    fuggvenyEredmenyMezo.innerHTML = "Fail";
    visszajelzesMezo.innerHTML = "Fail";
}
//1. feladat tesztek
function Teszt01() {
    try {
        FuggvenyVisszajelzoSor("Megtett út", "60,2", 120, MegtettUt(60, 2));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Megtett út", "60,2", 120);
    }
}
function Teszt02() {
    try {
        FuggvenyVisszajelzoSor("Megtett út", "120,3", 360, MegtettUt(120, 3));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Megtett út", "120,3", 360);
    }
}
function Teszt03() {
    try {
        FuggvenyVisszajelzoSor("Megtett út", "45,4", 180, MegtettUt(45, 4));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Megtett út", "45,4", 180);
    }
}
//2. feladat tesztek
function Teszt04() {
    try {
        FuggvenyVisszajelzoSor("Hőségriadó", "21,24,23", 0, HosegriadoSzint([21, 24, 23]));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Hőségriadó", "21,24,23", 0);
    }
}
function Teszt05() {
    try {
        FuggvenyVisszajelzoSor("Hőségriadó", "25,24,23", 1, HosegriadoSzint(25, 24, 23));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Hőségriadó", "25,24,23", 1);
    }
}
function Teszt06() {
    try {
        FuggvenyVisszajelzoSor("Hőségriadó", "25,26,26", 2, HosegriadoSzint(25, 26, 26));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Hőségriadó", "25,26,26", 2);
    }
}
function Teszt07() {
    try {
        FuggvenyVisszajelzoSor("Hőségriadó", "29,27,30", 3, HosegriadoSzint(29, 27, 30));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Hőségriadó", "29,27,30", 3);
    }
}
//3. feladat tesztek
function Teszt08() {
    try {
        FuggvenyVisszajelzoSor("Oszható számok", "3,[5,6,7,8,9]", 2, OszthatoSzamok(3, [5, 6, 7, 8, 9]));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Oszható számok", "3,[5,6,7,8,9]", 2);
    }
}
function Teszt09() {
    try {
        FuggvenyVisszajelzoSor("Oszható számok", "2,[4,6,7,8,10]", 4, OszthatoSzamok(2, [4, 6, 7, 8, 10]));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Oszható számok", "2,[4,6,7,8,10]", 4);
    }
}
function Teszt10() {
    try {
        FuggvenyVisszajelzoSor("Oszható számok", "7,[5,6,7,8,9,14,21]", 3, OszthatoSzamok(7, [5, 6, 7, 8, 9, 14, 21]));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Oszható számok", "7,[5,6,7,8,9,14,21]", 3);
    }
}
//4. feladat tesztek
function Teszt11() {
    try {
        FuggvenyVisszajelzoSor("Kör kerület, terület", "3", [18.8, 28.3], KorKeruletTerulet(3).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Kör kerület, terület", "3", [18.8, 28.3]);
    }
}
function Teszt12() {
    try {
        FuggvenyVisszajelzoSor("Kör kerület, terület", "4", [25.1, 50.3], KorKeruletTerulet(4).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Kör kerület, terület", "4", [25.1, 50.3]);
    }
}
function Teszt13() {
    try {
        FuggvenyVisszajelzoSor("Kör kerület, terület", "2", [12.6, 12.6], KorKeruletTerulet(2).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Kör kerület, terület", "2", [12.6, 12.6]);
    }
}
//5. feladat tesztek
function Teszt14() {
    try {
        FuggvenyVisszajelzoSor("Érettségi eredmény", "[15,20,15,30,25]", [105, 4], Erettsegi([15, 20, 15, 30, 25]).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Érettségi eredmény", "[15,20,15,30,25]", [105, 4]);
    }
}
function Teszt15() {
    try {
        FuggvenyVisszajelzoSor("Érettségi eredmény", "[5,10,5,10,10]", [40, 2], Erettsegi([5, 10, 5, 10, 10]).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Érettségi eredmény", "[5,10,5,10,10]", [40, 2]);
    }
}
function Teszt16() {
    try {
        FuggvenyVisszajelzoSor("Érettségi eredmény", "[15,30,15,45,30]", [135, 5], Erettsegi([15, 30, 15, 45, 30]).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Érettségi eredmény", "[15,30,15,45,30]", [105, 4]);
    }
}
function Teszt17() {
    try {
        FuggvenyVisszajelzoSor("Érettségi eredmény", "[1,5,5,2,3]", [16, 1], Erettsegi([1, 5, 5, 2, 3]).toString());
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Érettségi eredmény", "[1,5,5,2,3]", [16, 1]);
    }
}
//5. feladat tesztek
function Teszt18() {
    try {
        FuggvenyVisszajelzoSor("Leet kódolt szöveg", "Almafa", "4lm4f4", LeetKod("Almafa"));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Leet kódolt szöveg", "Almafa", "4lm4f4");
    }
}
function Teszt19() {
    try {
        FuggvenyVisszajelzoSor("Leet kódolt szöveg", "Szeretem a programozást", "Sz3r3t3m 4 pr0gr4m0zást", LeetKod("Szeretem a programozást"));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Leet kódolt szöveg", "Szeretem a programozást", "Sz3r3t3m 4 pr0gr4m0zást");
    }
}
function Teszt20() {
    try {
        FuggvenyVisszajelzoSor("Leet kódolt szöveg", "Typescript The Best", "Typ3scr1pt Th3 B3st", LeetKod("Typescript The Best"));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Leet kódolt szöveg", "Typescript The Best", "Typ3scr1pt Th3 B3st");
    }
}
function Teszt21() {
    try {
        FuggvenyVisszajelzoSor("Legnagyobb Snooker nyeremény", "Objektum", 1270500, LegtobbNyeremeny(snookerAdatok));
    }
    catch (_a) {
        HibasFuggvenyFuggvenyVisszajelzoSor("Legnagyobb Snooker nyeremény", "Objektum", 1270500);
    }
}
function TesztFuttato() {
    Teszt01();
    Teszt02();
    Teszt03();
    Teszt04();
    Teszt05();
    Teszt06();
    Teszt07();
    Teszt08();
    Teszt09();
    Teszt10();
    Teszt11();
    Teszt12();
    Teszt13();
    Teszt14();
    Teszt15();
    Teszt16();
    Teszt17();
    Teszt18();
    Teszt19();
    Teszt20();
    Teszt21();
}
TesztFuttato();

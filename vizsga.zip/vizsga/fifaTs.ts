const csapatAdat: string[] = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];

interface FifaAdat {
    nev: string;
    helyezes: number;
    valtozas: number;
    pont: number;
}

function ObjektumFeltolto(feltoltendoElem: string[]): FifaAdat[] {
    let beolvasottAdatok: FifaAdat[] = [];
    for (let i: number = 0; i < feltoltendoElem.length; i++) {
        let daraboltAdatok = feltoltendoElem[i].split(";");
        let ujCsapat: FifaAdat = {
            nev: daraboltAdatok[0],
            helyezes: Number(daraboltAdatok[1]),
            valtozas: Number(daraboltAdatok[2]),
            pont: Number(daraboltAdatok[3])
        }
        beolvasottAdatok.push(ujCsapat);
    }
    return beolvasottAdatok;
}
const fifaAdatok: FifaAdat[] = ObjektumFeltolto(csapatAdat);




//1. feladat - Adja meg aktuálisan hány csapat szerepel a ranglistán

function CsapatokSzama(vizsgaltTomb: FifaAdat[]): number {
    return vizsgaltTomb.length;
}

function CsapatokSzamaKiir(kiirandoErtek: number): void {
    console.log("A ranglistában szereplő csapatok száma: " + kiirandoErtek + " db");
}

CsapatokSzamaKiir(CsapatokSzama(fifaAdatok));




//2. feladat - Írja ki mennyi a résztvevő csapatok átlagpontszáma
function AtlagPontszam(vizsgaltTomb: FifaAdat[]): number {
    let osszeg: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        osszeg += vizsgaltTomb[i].pont;
    }
    return Math.round(osszeg / vizsgaltTomb.length);
}

function AtlagPontszamKiir(kiirandoErtek: number): void {
    console.log("A ranglistában szereplő csapatok átlagos pontszáma:" + kiirandoErtek)
}
AtlagPontszamKiir(AtlagPontszam(fifaAdatok));




//3. feladat - Listázza ki azokat a csapatokat, akik az átlagnál több pontot értek el
function AtlagFelettiek(vizsgaltTomb: FifaAdat[]): string[] {
    let atlagFelettiLista: string[] = [];
    let atlagPont: number = AtlagPontszam(vizsgaltTomb);
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].pont > atlagPont) {
            atlagFelettiLista.push(vizsgaltTomb[i].nev);
        }
    }
    return atlagFelettiLista;
}

function AtlagFelettiekKiir(kiirandoErtek: string[]): void {
    console.log("Átlag feletti csapatok listája:" + kiirandoErtek);
}
AtlagFelettiekKiir(AtlagFelettiek(fifaAdatok));




//4. feladat - Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma
function LegtobbetJavito(vizsgaltTomb: FifaAdat[]): number {
    let legtobbetJavitoIndexe: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].valtozas > vizsgaltTomb[legtobbetJavitoIndexe].valtozas) {
            legtobbetJavitoIndexe = i;
        }
    }
    return legtobbetJavitoIndexe;
}
function LegtobbetJavitoKiir(kiirandoIndexe: number): void {
    console.log("A legtöbbet javító csapat helyezése: " + fifaAdatok[kiirandoIndexe].helyezes);
    console.log("A legtöbbet javító csapat neve: " + fifaAdatok[kiirandoIndexe].nev);
    console.log("A legtöbbet javító csapat pontszáma: " + fifaAdatok[kiirandoIndexe].pont);
}
LegtobbetJavitoKiir(LegtobbetJavito(fifaAdatok));




//5. feladat - Határozza meg a adatok közöt megtalálható-e Magyarország csapata!
function SzerepelEMagyarorszag(vizsgaltTomb: FifaAdat[]): boolean {
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev == "Magyarország") {
            return true;
        }
    }
    return false;
}
function SzerepelEMagyarorszagKiir(benneVanE: boolean): void {
    if (benneVanE) { // vagy (eredmeny == true)
        console.log("Az országok listájában szerepel Magyarország!");
    }
    else {
        console.log("Az országok listájában NEM szerepel Magyarország.")
    }
}
SzerepelEMagyarorszagKiir(SzerepelEMagyarorszag(fifaAdatok));




//6. feladat - Készítsen  statisztikát  a  helyezések  változása  (Valtozas)  alapján  csoportosítva  a  csapatok számáról  a  minta  szerint!  Csak  azok  a  helyezésváltozások  jelenjenek  meg  a  képernyőn, amelyek esetében a csapatok száma több mint egy volt! A megjelenő csoportok sorrendje tetszőleges.

interface StatisztikaAdat {
    valtozasTipus: number;
    valtozasMennyiseg: number;
}

function Statisztika(vizsgaltTomb: FifaAdat[]): StatisztikaAdat[] {
    let statisztika: StatisztikaAdat[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE: boolean = false;
        let holSzerepel: number = 0;
        for (let j: number = 0; j < statisztika.length; j++) {
            if (vizsgaltTomb[i].valtozas == statisztika[j].valtozasTipus) {
                szerepelE = true;
                holSzerepel = j;
            }
        }
        if (!szerepelE) { //vagy (szerepelE == false)
            let ujElem: StatisztikaAdat = { valtozasTipus: vizsgaltTomb[i].valtozas, valtozasMennyiseg: 1 }
            statisztika.push(ujElem)
        }
        else {
            statisztika[holSzerepel].valtozasMennyiseg++;
        }
    }
    return statisztika;
}
function StatisztikaKiir(vizsgalatEredmenye: StatisztikaAdat[]): void {
    console.log("A változások mennyisége:")
    for (let i: number = 0; i < vizsgalatEredmenye.length; i++) {
        if (vizsgalatEredmenye[i].valtozasMennyiseg > 1) {
            console.log(vizsgalatEredmenye[i].valtozasTipus + ":" + vizsgalatEredmenye[i].valtozasMennyiseg);
        }
    }
}
StatisztikaKiir(Statisztika(fifaAdatok));